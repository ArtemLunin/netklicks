<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'ck09315_net' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'ck09315_net' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', 'M3DJ8vsM' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<]Bq[Jo^Q- L1_a(@n%z_>]ZbG4jt ZK%|`bH}!*!g4WH=vAJ06)~v9<8E^yml!W' );
define( 'SECURE_AUTH_KEY',  ':jr>W&6Z%sW/$?M@pEu6_8z6(R]Ks@SG#hBeGBZiZ!}w=[kQf)FZt8&nG7w6_BY%' );
define( 'LOGGED_IN_KEY',    'v/e~Ha$aCtd3SYjHLC(8vj[G}5hB(3},d3>9g$sTZvRm<?&-pmX@O,}+@D(!_H$M' );
define( 'NONCE_KEY',        '*|h>OKOY39)-zM9,^[&y6ce8xSYjFv.wV@,pDP-JHZ)e,S(1-][^}}c@SPMPgPn|' );
define( 'AUTH_SALT',        'd$R-8laWTt1)9W~ga8w~}-*nzUop>Jk8]&D%5mw] o7}qBK1txhmS#^W0~-dsul5' );
define( 'SECURE_AUTH_SALT', '?nn_-]L2Y;<B) ES`n5?Y_Mo]@d[ GL/Z&oi!<aP[Wz<)Lmam} i:JBl1q_<^N<J' );
define( 'LOGGED_IN_SALT',   'ZvpX$nAKp[2amh_$ (B;u0|#NkEKz&ZqzX]P?w1fz~/#taBTn!V8.I^gSClHkGvD' );
define( 'NONCE_SALT',       'ZsF h}(++h^(~Y0r8ex0[X!]vu?XXp-*#s1[+jsw7!fNf`4u1:kD9c7y1iH~AEZ%' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
